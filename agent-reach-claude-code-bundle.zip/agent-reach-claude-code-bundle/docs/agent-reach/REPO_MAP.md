# Agent Reach Repo Map

## What the repository is

Agent Reach is best understood as a **capability bootstrapper** for agents.
It gives an agent a standardized way to install and validate access to many public platforms, but the actual reads/searches are largely performed by upstream CLIs, public APIs, helper scripts, and MCP services.

## Structural decomposition

### 1. Package metadata
- `pyproject.toml`
  - package metadata
  - dependencies
  - console entry point
  - wheel packaging rules

### 2. Root project memory
- `CLAUDE.md`
  - upstream project instructions
  - architecture summary
  - development rules
  - test commands

### 3. Main package
- `agent_reach/cli.py`
  - CLI entry point
  - install / doctor / configure / helper commands
- `agent_reach/core.py`
  - routing logic for reads and searches
- `agent_reach/config.py`
  - local configuration persistence
- `agent_reach/doctor.py`
  - diagnostics and channel health checks

### 4. Platform channels
- `agent_reach/channels/`
  - one channel file per platform
  - channel abstraction around read/search/check behavior
- `agent_reach/channels/base.py`
  - common interface / shared logic

### 5. Integrations
- `agent_reach/integrations/mcp_server.py`
  - MCP-oriented integration glue
- `config/mcporter.json`
  - tool configuration for mcporter-backed capabilities

### 6. Skill packaging
- `agent_reach/skill/SKILL.md`
  - upstream skill-oriented usage guide
  - practical command reference for supported platforms

### 7. Human/agent operational docs
- `docs/install.md`
  - installation workflow
  - safety boundaries
  - directory rules
  - credential flows
- `docs/update.md`
  - upgrade workflow
  - verification steps

### 8. Tests
- `tests/`
  - CLI and package validation
- `test.sh`
  - larger integration test flow

## Architectural interpretation

This repo is not a classical “single API abstraction” library.
It is closer to:
- bootstrapper
- health checker
- platform config manager
- command reference
- glue code for external tools

That distinction matters when porting it into Claude Code.
