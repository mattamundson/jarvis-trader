# Agent Reach Platform Matrix

## Broad capability groups

### No/low-friction channels
These are easiest to operationalize because they rely on public endpoints or simple tools.

- Generic web pages
- RSS
- YouTube metadata/subtitles
- GitHub public repo workflows
- Weibo public functions
- V2EX public API
- Xueqiu public data

### Medium-friction channels
These work, but may need environment-specific adjustments.

- Reddit on server IPs
- Bilibili on server IPs
- LinkedIn richer workflows via MCP/service setup
- Exa search via `mcporter`

### High-friction channels
These often require cookies, proxies, Docker, or extra MCP services.

- Twitter/X search/posting
- XiaoHongShu
- Douyin advanced setup
- Xiaoyuzhou transcription

## Representative tool mapping

| Platform | Primary Surface | Notes |
|---|---|---|
| Web | `curl` + Jina Reader | clean webpage extraction |
| Search | `mcporter` + Exa | semantic search |
| Twitter/X | `bird` | cookies often required for advanced use |
| YouTube | `yt-dlp` | metadata + subtitles |
| Bilibili | `yt-dlp` | server IPs may need cookies/proxy |
| Reddit | `curl` public JSON | server IPs may need proxy or fallback search |
| GitHub | `gh` | public/private depth depends on auth |
| XiaoHongShu | `mcporter` + MCP | login/cookies required |
| Douyin | `mcporter` + MCP | separate HTTP service setup |
| Weibo | `mcporter` | public access model |
| WeChat Articles | python helper + Camoufox | cannot rely on simple Jina/curl read path |
| Xiaoyuzhou | shell script + Groq Whisper | free key required |
| LinkedIn | `mcporter` or Jina fallback | richer use requires MCP/service |
| V2EX | public API | no auth |
| Xueqiu | public API wrappers | no auth |
| RSS | `feedparser` | no auth |
