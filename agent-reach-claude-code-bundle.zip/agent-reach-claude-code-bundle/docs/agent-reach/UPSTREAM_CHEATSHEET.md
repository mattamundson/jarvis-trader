# Agent Reach Upstream Cheatsheet

Use this after Agent Reach is already installed and healthy.

## Generic webpage
```bash
curl -s "https://r.jina.ai/https://example.com"
```

## Search the web
```bash
mcporter call 'exa.web_search_exa(query: "latest model context windows", numResults: 5)'
```

## Read a tweet or search X
```bash
bird read https://x.com/user/status/123
bird search "agentic coding" -n 10
```

## Search YouTube and fetch subtitles
```bash
yt-dlp --dump-json "ytsearch5:anthropic claude code"
yt-dlp --write-sub --write-auto-sub --sub-lang "en" --skip-download -o "/tmp/%(id)s" "https://www.youtube.com/watch?v=VIDEO_ID"
```

## Search GitHub repos
```bash
gh search repos "claude code tools" --sort stars --limit 10
```

## Search Reddit public JSON
```bash
curl -s "https://www.reddit.com/search.json?q=claude%20code&limit=10" -H "User-Agent: agent-reach/1.0"
```

## Search XiaoHongShu
```bash
mcporter call 'xiaohongshu.search_feeds(keyword: "AI Agent")'
```

## Parse Douyin video
```bash
mcporter call 'douyin.parse_douyin_video_info(share_link: "https://v.douyin.com/xxx/")'
```

## Weibo trends
```bash
mcporter call 'weibo.get_trendings(limit: 20)'
```

## LinkedIn profile lookup
```bash
mcporter call 'linkedin.get_person_profile(linkedin_url: "https://linkedin.com/in/username")'
```
