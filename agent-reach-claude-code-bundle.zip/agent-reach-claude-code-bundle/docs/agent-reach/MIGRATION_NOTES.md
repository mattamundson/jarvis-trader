# Migration Notes — OpenClaw Skill to Claude Code

## The conversion problem

The upstream repository already contains a `SKILL.md`, but that does not automatically mean Claude Code uses the same skill discovery/runtime model.

A robust Claude Code port should therefore separate concerns:

- **Always-on memory** → `CLAUDE.md`
- **Reusable specialized behavior** → `.claude/agents/*.md`
- **Explicit user-invoked flows** → `.claude/commands/*.md`
- **Long-form references** → `docs/*.md`
- **Cross-tool portability** → preserved `SKILL.md`

## Why this split is better

### `CLAUDE.md`
Use for:
- architecture
- repo rules
- boundary conditions
- command preferences
- persistent behavior

### `.claude/agents/`
Use for:
- installation operator
- diagnostics specialist
- repo porter/migrator
- channel author/extender

### `.claude/commands/`
Use for:
- `/install-agent-reach`
- `/update-agent-reach`
- `/agent-reach-doctor`
- any repeatable explicit workflow

### `docs/`
Use for:
- dense command references
- platform matrixes
- troubleshooting trees
- migration rationale

## Optional further decomposition

If you want a larger Claude Code package, the next files I would add are:

- `.claude/agents/agent-reach-channel-author.md`
- `.claude/agents/agent-reach-troubleshooter.md`
- `.claude/commands/configure-twitter-cookies.md`
- `.claude/commands/configure-xhs.md`
- `.claude/commands/configure-proxy.md`
- `docs/agent-reach/TROUBLESHOOTING.md`
- `docs/agent-reach/COOKIES_AND_AUTH.md`
- `docs/agent-reach/NETWORK_AND_PROXY.md`
- `docs/agent-reach/EXTENDING_CHANNELS.md`

## Recommended usage model in Claude Code

1. Put the root `CLAUDE.md` in the project or merge into your user memory.
2. Put the subagent under `.claude/agents/` or `~/.claude/agents/`.
3. Put the command files under `.claude/commands/` or `~/.claude/commands/`.
4. Keep the `SKILL.md` as a portability artifact and dense reference, not as the only integration mechanism.
