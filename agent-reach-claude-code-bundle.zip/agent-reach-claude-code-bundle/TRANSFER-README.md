# Agent Reach → Claude Code Transfer Bundle

This bundle converts the public Agent Reach repository into a Claude Code-friendly structure.

## What is included

- `CLAUDE.md`
  - Project memory for Claude Code.
  - High-value architectural context, repo rules, install/update boundaries, and decision rules.
- `.claude/agents/agent-reach-operator.md`
  - A Claude Code subagent for installation, diagnostics, configuration, and usage.
- `.claude/commands/install-agent-reach.md`
  - One-shot command for installation workflow.
- `.claude/commands/update-agent-reach.md`
  - One-shot command for upgrades + verification.
- `.claude/commands/agent-reach-doctor.md`
  - One-shot command for diagnostics + remediation workflow.
- `skills/agent-reach/SKILL.md`
  - Preserved skill-style packaging derived from the upstream project.
  - Useful for systems that consume `SKILL.md`, and as a knowledge resource inside Claude Code.
- `docs/agent-reach/*.md`
  - Repo map, platform matrix, usage cheat sheet, and migration notes.

## Recommended placement

### Option A — project-local Claude Code setup
Copy these into the repository where you want Claude Code to use Agent Reach knowledge:

- `CLAUDE.md` → repo root
- `.claude/agents/*` → repo `.claude/agents/`
- `.claude/commands/*` → repo `.claude/commands/`
- `docs/agent-reach/*` → repo `docs/agent-reach/`

### Option B — personal/global Claude Code setup
Copy these into your user-level Claude folders:

- `CLAUDE.md` → merge selectively into `~/.claude/CLAUDE.md`
- `.claude/agents/agent-reach-operator.md` → `~/.claude/agents/`
- `.claude/commands/*.md` → `~/.claude/commands/`
- `docs/agent-reach/*` → anywhere you want as reference material

## Important note

Claude Code natively documents and supports:
- `CLAUDE.md`
- `.claude/commands/*.md`
- `.claude/agents/*.md`
- `.claude/settings.json`

This bundle therefore converts the upstream OpenClaw-style skill into Claude-native memory, command, and subagent primitives while also preserving a standalone `SKILL.md` for portability.
