# Agent Reach — Claude Code Project Memory

## Purpose

Agent Reach is a Python CLI + library that gives AI agents read/search access to many public internet platforms.
It is an installer, doctor, and configuration layer.
It is **not** the primary runtime wrapper after installation.
After setup, prefer calling the upstream tools directly.

## Positioning

Use Agent Reach when the task involves any of the following:
- Reading arbitrary web pages cleanly
- Searching web/social/video/community sources without paid APIs
- Fetching video metadata/subtitles/transcripts
- Reading GitHub repositories and issues from CLI
- Handling platform-specific setup such as cookies, MCP tools, proxies, or Docker-backed connectors
- Running diagnostics when internet channels stop working

## Core model

Think of the system in four layers:
1. **Installer** — installs Python package and external dependencies
2. **Doctor** — checks channel health and suggests repairs
3. **Configurator** — stores tokens/cookies/proxy settings
4. **Upstream executors** — `yt-dlp`, `gh`, `mcporter`, `curl`, platform MCP servers, and helper scripts

Always remember: after install, **upstream tools are the operational surface area**.

## Canonical repo facts

- Package name: `agent-reach`
- Version referenced upstream: `1.3.0`
- License: MIT
- Python requirement: 3.10+
- Entry point: `agent_reach.cli:main`

## Repository structure

- `agent_reach/cli.py` — CLI entry point
- `agent_reach/core.py` — core read/search routing logic
- `agent_reach/config.py` — config management
- `agent_reach/doctor.py` — diagnostics engine
- `agent_reach/channels/` — one file per platform
- `agent_reach/channels/base.py` — shared channel contract
- `agent_reach/integrations/mcp_server.py` — MCP integration layer
- `agent_reach/skill/` — upstream skill packaging
- `tests/` — pytest coverage
- `config/mcporter.json` — MCP tool config

## Operating rules

- Never reframe Agent Reach as a monolithic wrapper.
- Prefer public CLIs and documented interfaces over private internals.
- Do not modify upstream third-party tools unless explicitly requested.
- Keep all persistent Agent Reach state outside the active workspace.
- Use `/tmp/` for temp output.
- Use `~/.agent-reach/` for persistent data.
- Do not create random repos or files inside the user's current project during install/update flows.
- Do not use QR login when the upstream guidance says Cookie-Editor is preferred.
- For Twitter/X and XiaoHongShu cookie flows, prefer Cookie-Editor export/import.

## Directory rules

Use these locations:

- Config and tokens: `~/.agent-reach/`
- Upstream tool repos: `~/.agent-reach/tools/`
- Temp files: `/tmp/`
- Optional skill files for skill-based systems: `~/.openclaw/skills/agent-reach/`

## Primary commands

### Install
```bash
pip install https://github.com/Panniantong/agent-reach/archive/main.zip
agent-reach install --env=auto
```

### Safe install
```bash
pip install https://github.com/Panniantong/agent-reach/archive/main.zip
agent-reach install --env=auto --safe
```

### Dry run
```bash
agent-reach install --env=auto --dry-run
```

### Verify
```bash
agent-reach doctor
```

### Update
```bash
agent-reach check-update
pip install --upgrade https://github.com/Panniantong/agent-reach/archive/main.zip
agent-reach version
agent-reach doctor
```

## Supported operational surfaces

### General web
```bash
curl -s "https://r.jina.ai/URL"
```

### Exa search through mcporter
```bash
mcporter call 'exa.web_search_exa(query: "query", numResults: 5)'
mcporter call 'exa.get_code_context_exa(query: "code question", tokensNum: 3000)'
```

### Twitter/X
```bash
bird search "query" -n 10
bird read URL_OR_ID
bird user-tweets @username -n 20
bird thread URL_OR_ID
```

### YouTube / Bilibili
```bash
yt-dlp --dump-json "URL"
yt-dlp --write-sub --write-auto-sub --sub-lang "zh-Hans,zh,en" --skip-download -o "/tmp/%(id)s" "URL"
```

### GitHub
```bash
gh search repos "query" --sort stars --limit 10
gh repo view owner/repo
gh issue list -R owner/repo --state open
gh issue view 123 -R owner/repo
```

### Reddit
```bash
curl -s "https://www.reddit.com/search.json?q=QUERY&limit=10" -H "User-Agent: agent-reach/1.0"
```

## Channel contract (for code work)

When editing or extending channels, assume a base interface with:
- `can_handle(url)`
- `read(url)`
- `search(query)`
- `check()`

Each channel should remain isolated and platform-specific.

## Development conventions

- Python 3.10+ with type hints
- `loguru` for logging
- `rich` for CLI output
- Commit format: `type(scope): message`
- Run tests before proposing completion

## Test commands
```bash
pip install -e .
pytest tests/ -v
pytest tests/test_cli.py -v
bash test.sh
```

## Version consistency rule

If editing the actual upstream repo or a fork, keep version references aligned across:
- `pyproject.toml`
- `__init__.py`
- `tests/test_cli.py`

## Claude Code behavior guidance

When the user asks Claude Code to use Agent Reach:
- First decide whether the task is install/update/doctor/use/extend.
- For install/update/doctor, prefer the custom commands or subagent in this bundle.
- For usage tasks, call upstream tools directly once the environment is healthy.
- For channel failures, run `agent-reach doctor` before inventing ad hoc fixes.
- For auth-gated platforms, ask only for credentials or cookies the user must provide.
- Do not ask the user to manually perform internal integration steps that Claude can do itself.
