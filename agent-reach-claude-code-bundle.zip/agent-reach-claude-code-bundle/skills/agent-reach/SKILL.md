---
name: agent-reach
description: >
  Give your AI agent eyes to see the entire internet.
  Search and read 17 platforms: Twitter/X, Reddit, YouTube, GitHub, Bilibili,
  XiaoHongShu, Douyin, Weibo, WeChat Articles, Xiaoyuzhou Podcast, LinkedIn,
  V2EX, Xueqiu, RSS, Exa web search, and any web page.
  Zero config for several channels. Use when the user asks to search, read, or interact
  on supported platforms, shares a URL, or asks to search the web.
metadata:
  portability:
    target_systems:
      - Claude Code
      - OpenClaw
      - Cursor
      - Windsurf
    note: This file is preserved for portability. Claude Code should primarily use CLAUDE.md, .claude/agents, and .claude/commands.
---

# Agent Reach — Portable Skill Reference

## Use this skill when

- The user wants a webpage read cleanly
- The user wants social/video/community search without paid APIs
- A URL from a supported platform needs structured extraction
- Agent Reach needs installation, update, or diagnostics

## Core rule

Agent Reach is an **installer + doctor + config layer**.
After setup, call upstream tools directly.

## Workspace rule

Never create Agent Reach state in the active project workspace.
Use:
- `~/.agent-reach/` for persistent data
- `/tmp/` for temporary output

## Essential commands

### Install
```bash
pip install https://github.com/Panniantong/agent-reach/archive/main.zip
agent-reach install --env=auto
```

### Safe install
```bash
pip install https://github.com/Panniantong/agent-reach/archive/main.zip
agent-reach install --env=auto --safe
```

### Verify
```bash
agent-reach doctor
```

### Update
```bash
agent-reach check-update
pip install --upgrade https://github.com/Panniantong/agent-reach/archive/main.zip
agent-reach version
agent-reach doctor
```

## Upstream usage cheat sheet

### Web
```bash
curl -s "https://r.jina.ai/URL"
```

### Exa web search
```bash
mcporter call 'exa.web_search_exa(query: "query", numResults: 5)'
mcporter call 'exa.get_code_context_exa(query: "code question", tokensNum: 3000)'
```

### Twitter/X
```bash
bird search "query" -n 10
bird read URL_OR_ID
bird user-tweets @username -n 20
bird thread URL_OR_ID
```

### YouTube
```bash
yt-dlp --dump-json "URL"
yt-dlp --write-sub --write-auto-sub --sub-lang "zh-Hans,zh,en" --skip-download -o "/tmp/%(id)s" "URL"
yt-dlp --dump-json "ytsearch5:query"
```

### Reddit
```bash
curl -s "https://www.reddit.com/search.json?q=QUERY&limit=10" -H "User-Agent: agent-reach/1.0"
```

### GitHub
```bash
gh search repos "query" --sort stars --limit 10
gh repo view owner/repo
gh issue list -R owner/repo --state open
gh issue view 123 -R owner/repo
```

### XiaoHongShu
```bash
mcporter call 'xiaohongshu.search_feeds(keyword: "query")'
mcporter call 'xiaohongshu.get_feed_detail(feed_id: "xxx", xsec_token: "yyy")'
```

### Douyin
```bash
mcporter call 'douyin.parse_douyin_video_info(share_link: "https://v.douyin.com/xxx/")'
mcporter call 'douyin.get_douyin_download_link(share_link: "https://v.douyin.com/xxx/")'
```

### Weibo
```bash
mcporter call 'weibo.get_trendings(limit: 20)'
mcporter call 'weibo.search_content(keyword: "人工智能", limit: 20)'
```

### LinkedIn
```bash
mcporter call 'linkedin.get_person_profile(linkedin_url: "https://linkedin.com/in/username")'
mcporter call 'linkedin.search_people(keyword: "AI engineer", limit: 10)'
```

### RSS
```bash
python3 -c "import feedparser; [print(f'{e.title} — {e.link}') for e in feedparser.parse('FEED_URL').entries[:5]]"
```

## Credential handling

- Prefer Cookie-Editor export for cookie-based platforms.
- Recommend secondary accounts for high-risk cookie auth.
- Ask only for the minimum user-provided secrets required to finish setup.

## Troubleshooting

1. Run `agent-reach doctor`
2. Fix local dependencies first
3. Then proxies/network
4. Then auth/cookies
5. Then Docker/MCP services
