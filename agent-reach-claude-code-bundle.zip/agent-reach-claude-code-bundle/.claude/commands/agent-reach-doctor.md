---
description: Run Agent Reach diagnostics, classify failures, remediate what can be fixed automatically, and ask only for required credentials or permissions.
---

Run an Agent Reach diagnostic/remediation pass.

Workflow:

1. Execute:
```bash
agent-reach doctor
```

2. Classify each non-healthy channel as one of:
- missing dependency
- missing cookies/auth
- missing proxy
- MCP service not configured
- Docker/service not running
- external platform/network limitation

3. Fix everything you can fix directly without asking me.

4. Only ask me for inputs that only I can provide, such as:
- cookies
- proxy URL
- API key
- approval for elevated/system changes

5. End with a concise matrix:
- healthy
- partially available
- blocked pending user input
- blocked by environment/platform
