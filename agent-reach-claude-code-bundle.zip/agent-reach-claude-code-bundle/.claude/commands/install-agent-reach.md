---
description: Install Agent Reach using the upstream workflow, verify with doctor, and summarize what still needs user input.
---

Install Agent Reach using the upstream project workflow.

Requirements for this command:
- Do not create unrelated files in the active workspace.
- Prefer `~/.agent-reach/` for persistent state and `/tmp/` for temporary files.
- Do not use `sudo` unless I explicitly approve.
- If the machine looks sensitive or production-like, prefer `--safe` and explain the tradeoff.

Execution sequence:

1. Install:
```bash
pip install https://github.com/Panniantong/agent-reach/archive/main.zip
agent-reach install --env=auto
```

2. Verify:
```bash
agent-reach doctor
```

3. Summarize:
- Which channels are healthy
- Which channels need config
- Exactly what inputs you still need from me, if any

If install fails because of environment/package-management constraints, fall back to the safest equivalent approach and explain why.
