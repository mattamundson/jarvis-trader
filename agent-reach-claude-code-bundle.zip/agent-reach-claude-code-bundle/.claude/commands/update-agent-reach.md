---
description: Update Agent Reach to the latest upstream version, re-run doctor, and report version plus channel changes.
---

Update Agent Reach using the upstream update flow.

Execution sequence:

1. Check status:
```bash
agent-reach check-update
```

2. Upgrade:
```bash
pip install --upgrade https://github.com/Panniantong/agent-reach/archive/main.zip
```

3. Verify:
```bash
agent-reach version
agent-reach doctor
```

4. Summarize:
- old vs new version if available
- channels that stayed healthy
- channels that regressed
- channels that improved
- anything that now requires my input

Do not claim success unless the verification step completes.
