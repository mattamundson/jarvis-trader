# Mean-Reversion v2 — Phase 2 staging

This directory contains files that need to be COPIED into your local
jarvis-trader repo before the funnel can run them as Phase 2 candidates.

## Install

```powershell
# From your jarvis-trader repo root
copy "<this dir>\engine_backtest\meanrev_v2_signals.py" engine\backtest\
copy "<this dir>\engine_backtest\run_mes_meanrev_v2_rank1.py" engine\backtest\
copy "<this dir>\engine_backtest\run_mgc_meanrev_v2_rank1.py" engine\backtest\
copy "<this dir>\engine_tests\test_meanrev_v2_signals.py" engine\tests\
```

## Validate

```powershell
cd engine
.venv\Scripts\python -m pytest tests\test_meanrev_v2_signals.py -v
```

All 14 tests should pass; 1 skip expected (regime-detection test needs more data).

## Run

The runners are SHELLS that need to be wired into your WFO orchestration code.
See `run_mes_meanrev_v2_rank1.py::main()` for the integration pattern. Briefly:

1. The v1 runner `run_mes_meanrev_rank1.py` has all the WFO mechanics.
2. The v2 runner imports `meanrev_v2_signals.generate_meanrev_v2_signals`.
3. Replace the signal-generator call in the v1 WFO loop with the v2 factory.
4. Change the verdict output path.
5. Done.

Recommended refactor: extract the WFO mechanics into `wfo_primitives.run_wfo(signal_fn, grid, ...)`
so v1 and v2 share the same orchestration.

## What the three fixes solve

See `references/meanrev_audit.md` for the full diagnosis. Briefly:

| Failure (v1) | Fix (v2) |
|---|---|
| Static 2σ Bollinger trigger assumes stationary vol | Rolling 95th-percentile dislocation trigger (auto-recalibrates to vol regime) |
| Fixed 1.5×ATR(14) stop too tight in vol expansion | Max of short-window ATR and 75th-percentile of long-window ATR + time stop + trail to BE |
| No cluster-loss circuit breaker | Strategy-level breaker on rolling-5 PnL, 3 consecutive stops, daily loss cap |
| OU module exists but unused | OU half-life filter (mode="filter") or OU z-score trigger (mode="zscore_trigger") |
