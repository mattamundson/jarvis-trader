# Install in Claude Code

## Option 1: Project skill

Put the folder in the repository you want Claude Code to use:

```bash
mkdir -p .claude/skills
cp -R n-autoresearch-skill .claude/skills/n-autoresearch
```

Then make sure the folder contains:

```text
.claude/
  skills/
    n-autoresearch/
      SKILL.md
      references/
      templates/
      examples/
```

Important:
- the directory name should match the skill `name`
- if you rename the folder to `n-autoresearch`, also keep the `name` in `SKILL.md` as `n-autoresearch`

## Option 2: Personal skill

Install for all repos:

```bash
mkdir -p ~/.claude/skills
cp -R n-autoresearch-skill ~/.claude/skills/n-autoresearch
```

## ZIP packaging

If you are importing/uploading a packaged skill, zip the skill folder itself as the root item.

Correct:

```text
n-autoresearch.zip
└── n-autoresearch/
    ├── SKILL.md
    ├── references/
    ├── templates/
    └── examples/
```

Incorrect:

```text
n-autoresearch.zip
├── SKILL.md
├── references/
└── templates/
```

## Suggested first test prompts

- `Read program.md and kick off a new experiment.`
- `Summarize the best kept experiments for tag mar11.`
- `Suggest the next architecture experiment for the current run tag.`
- `Operate n-autoresearch but only modify train.py.`

## Recommended refinement

If you want stricter behavior, add repository-specific examples to `examples/` and tune the description in `SKILL.md` so Claude activates it only for this repo.
