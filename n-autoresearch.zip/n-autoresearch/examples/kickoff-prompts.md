# Kickoff prompts

Use these prompts to trigger the skill cleanly in Claude Code.

## Start a run

```text
Read program.md, initialize a new run tag, and kick off a baseline experiment.
```

## Run autonomously within repo rules

```text
Operate the n-autoresearch loop. Edit only train.py, register each experiment, and obey keep vs reset decisions.
```

## Conservative mode

```text
Run the n-autoresearch experiment loop, but stay conservative: prioritize simplification, small diffs, and low-crash changes.
```

## Strategy review

```text
Summarize the current tag's best experiments, near-misses, and underexplored categories, then recommend the next two experiments.
```

## Multi-GPU mode

```text
Use the GPU pool endpoints, acquire a GPU before training, and release it after each experiment.
```
